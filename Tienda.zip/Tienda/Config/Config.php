<?php
const BASE_URL = "http://localhost/tienda/";
const HOST = "localhost";
const USER = "sql8736543";
const PASS = "lcKEvd1C9Z";
const DB = "sql8736543";
const CHARSET = "charset=utf8";
const TITLE = "TIENDA ONLINE";
const MONEDA = "MXN";
const CLIENT_ID = "";

const USER_SMTP = "Tu correo";
const PASS_SMTP = "contraseña generada para esta aplicacion";
const PUERTO_SMTP = 465;
const HOST_SMTP = "smtp.gmail.com";
?>
